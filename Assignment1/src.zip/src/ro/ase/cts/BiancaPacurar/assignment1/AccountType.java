package ro.ase.cts.BiancaPacurar.assignment1;

public enum AccountType {
	 STANDARD, BUGET, PREMIUM, SUPER_PREMIUM
}
