package ro.ase.cts.BiancaPacurar.assignment1;

public class InvalidLoanValueException extends Exception{
	
}
