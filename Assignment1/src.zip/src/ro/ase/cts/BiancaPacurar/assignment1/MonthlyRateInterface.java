package ro.ase.cts.BiancaPacurar.assignment1;

public interface MonthlyRateInterface {
	double getMonthlyRate();
}
